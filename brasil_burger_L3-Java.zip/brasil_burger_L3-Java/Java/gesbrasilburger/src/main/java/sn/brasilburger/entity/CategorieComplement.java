package sn.brasilburger.entity;

public enum CategorieComplement {
    FRITES,
    BOISSON
}
