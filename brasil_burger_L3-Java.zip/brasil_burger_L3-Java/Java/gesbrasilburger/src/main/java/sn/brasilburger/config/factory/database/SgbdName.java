package sn.brasilburger.config.factory.database;

public enum SgbdName {
    MYSQL, POSTGRESQL
}
