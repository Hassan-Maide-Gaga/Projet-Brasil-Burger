package sn.brasilburger.config.factory;

public enum EntityName {
    BURGER, COMPLEMENT,LIVREUR,LOGIN,MENU,ZONE,MENU_COMPLEMENT, IMAGE_UPLOAD
}
