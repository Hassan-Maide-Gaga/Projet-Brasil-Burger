package sn.brasilburger.repository;

import sn.brasilburger.entity.MenuComplement;

public interface MenuComplementRepository {
    boolean insert(MenuComplement menuC);
}
