package sn.brasilburger.entity;

public enum RoleUser {
    GESTIONNAIRE,
    CLIENT
}
