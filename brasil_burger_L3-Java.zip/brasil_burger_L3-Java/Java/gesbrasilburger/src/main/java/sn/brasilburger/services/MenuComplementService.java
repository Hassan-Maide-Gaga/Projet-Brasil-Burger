package sn.brasilburger.services;

import sn.brasilburger.entity.MenuComplement;

public interface MenuComplementService {
    boolean createMenuComplement(MenuComplement menuC);
}
